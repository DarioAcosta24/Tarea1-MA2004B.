﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1.Clases
{
    public class Aleatorio
    {
        public long Id { get; set; }
        public int Valor { get; set; }
        public int Posicion { get; set; }
        public Aleatorio() { }
    }
}
